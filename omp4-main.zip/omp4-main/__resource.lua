resource_manifest_version 'f15e72ec-3972-4fe4-9c7d-afc5394ae207'

this_is_a_map 'yes'
client_script "@Badger-Anticheat/acloader.lua"